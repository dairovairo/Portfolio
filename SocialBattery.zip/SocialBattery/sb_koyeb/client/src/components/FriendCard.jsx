import { getBatteryColor, formatRelativeTime } from '../lib/battery';
import { isOnline } from '../hooks/usePresence';
import { useSettings } from '../context/SettingsContext';

export default function FriendCard({ friend, online: onlineProp, onClick }) {
  const color = getBatteryColor(friend.battery_level ?? 50);
  const { showLastSeen } = useSettings();
  // If caller passes online prop (reactive), use it; otherwise fall back to local check
  const online = onlineProp !== undefined ? onlineProp : isOnline(friend.last_seen_at);

  return (
    <button
      onClick={onClick}
      className="w-full bg-surface-card hover:bg-surface-hover border border-surface-border rounded-2xl p-4 flex items-center gap-4 transition-all duration-200 text-left group"
    >
      {/* Avatar */}
      <div className="relative flex-shrink-0">
        <div
          className="w-12 h-12 rounded-full flex items-center justify-center text-xl font-display font-bold border-2 transition-all duration-200"
          style={{
            borderColor: color.hex,
            boxShadow: `0 0 12px ${color.hex}30`,
            background: `${color.hex}15`,
          }}
        >
          {friend.avatar_url ? (
            <img src={friend.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
          ) : (
            (friend.display_name || friend.username)?.[0]?.toUpperCase()
          )}
        </div>
        {/* Online dot */}
        <span className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-surface-card ${online ? 'bg-green-400' : 'bg-slate-600'}`} />
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-display font-semibold text-surface-text truncate">
            {friend.display_name || friend.username}
          </span>
          {friend.battery_is_estimated && (
            <span className="text-xs bg-yellow-500/20 text-yellow-400 px-1.5 py-0.5 rounded font-mono flex-shrink-0">
              ⚡est.
            </span>
          )}
        </div>
        <div className="text-xs text-surface-muted font-mono mt-0.5">
          @{friend.username}
        </div>
        {showLastSeen && (
          <div className="text-xs text-surface-muted mt-1">
            Última actualización: {formatRelativeTime(friend.battery_updated_at)}
          </div>
        )}
      </div>

      {/* Battery level */}
      <div className="flex-shrink-0 text-right">
        <div
          className="font-display text-2xl font-bold tabular-nums transition-colors duration-200"
          style={{ color: color.hex }}
        >
          {friend.battery_level ?? '—'}
        </div>
        <div className="text-xs text-surface-muted font-mono">%</div>
      </div>

      {/* Mini bar — fills bottom to top */}
      <div className="w-1.5 h-12 bg-surface-bg rounded-full flex-shrink-0 overflow-hidden relative">
        <div
          className="absolute bottom-0 w-full rounded-full transition-all duration-500"
          style={{
            height: `${friend.battery_level ?? 0}%`,
            backgroundColor: color.hex,
            boxShadow: `0 0 8px ${color.hex}`,
          }}
        />
      </div>
    </button>
  );
}
